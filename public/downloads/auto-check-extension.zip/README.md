# Auto-Check Browser Extension v1.0.0

## Installation Instructions
1. Open Google Chrome and navigate to `chrome://extensions/`.
2. Enable **Developer mode** toggle in the top-right corner.
3. Unzip this package, or click **Load unpacked** and select the unzipped directory.
4. Pin the Auto-Check icon to your toolbar.
5. Click the icon to view your license status and enter your v2 license key.

## Fail-Open Security Architecture
- **Fail-Open Core Gate**: Active users with valid licenses will never be interrupted during automated check-ins when encountering transient network or server outages.
- **Privacy Assurance**: Your student passwords, school cookies, and credentials remain entirely local on your machine and are never transmitted to our servers.

For assistance, visit: https://auto-check.example/support
