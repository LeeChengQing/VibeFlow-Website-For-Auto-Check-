# Auto-Check Browser Extension v1.0.0

## Installation Instructions
1. Open Google Chrome and navigate to `chrome://extensions/`.
2. Enable **Developer mode** toggle in the top-right corner.
3. Unzip this folder, or click **Load unpacked** and select the unzipped directory.
4. Pin the Auto-Check icon to your toolbar.
5. Click the icon to view your license status and configure settings.

For assistance, visit: https://auto-check.example/support
