// Auto-Check MV3 Background Service Worker
// Fail-open for previously activated users: network errors do not block existing users.
self.addEventListener('install', () => {
  console.log('[Auto-Check] Extension installed.');
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkin-refresh') {
    console.log('[Auto-Check] Check-in alarm triggered.');
  }
});
