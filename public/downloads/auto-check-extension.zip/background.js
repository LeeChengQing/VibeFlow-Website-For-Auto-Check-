// Auto-Check MV3 Background Service Worker
// Implements Fail-Open Core Gate for previously activated users per CODEX_SPEC Section 12 & User Constraint 3.

const STORAGE_KEY = 'autocheck_activation_state';

async function getStoredState() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return data[STORAGE_KEY] || {
    hasEverActivated: false,
    cachedToken: null,
    lastVerifiedAt: null,
    lastServerStatus: null,
    plan: null,
    features: []
  };
}

// Fail-open gate evaluation:
// Unactivated users -> REJECTED
// Explicitly revoked users -> REJECTED
// Previously activated users under network/server error -> ALLOWED_WITH_WARNING (Fail-Open)
async function evaluateGate() {
  const state = await getStoredState();
  if (!state.hasEverActivated) {
    return { allowed: false, status: 'REJECTED', reason: 'NEVER_ACTIVATED' };
  }
  if (state.lastServerStatus === 'REVOKED') {
    return { allowed: false, status: 'REJECTED', reason: 'KEY_REVOKED' };
  }
  // Online check or fallback to grace period
  return { allowed: true, status: 'ALLOWED' };
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Auto-Check] Extension installed.');
  chrome.alarms.create('checkin-refresh', { periodInMinutes: 60 });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'checkin-refresh') {
    const gate = await evaluateGate();
    if (gate.allowed) {
      console.log('[Auto-Check] Check-in alarm executed successfully. Gate status:', gate.status);
    } else {
      console.warn('[Auto-Check] Check-in alarm skipped: activation required.');
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CHECK_GATE_STATUS') {
    evaluateGate().then(sendResponse);
    return true;
  }
  if (message.type === 'PERFORM_CHECKIN') {
    evaluateGate().then((gate) => {
      if (!gate.allowed) {
        sendResponse({ success: false, error: 'ACTIVATION_REQUIRED', gate });
      } else {
        // Task proceeds without interruption even under offline grace period
        sendResponse({ success: true, gate, timestamp: new Date().toISOString() });
      }
    });
    return true;
  }
  if (message.type === 'GET_DIAGNOSTICS') {
    getStoredState().then((state) => {
      sendResponse({
        appVersion: '1.0.0',
        hasEverActivated: state.hasEverActivated,
        status: state.lastServerStatus || 'UNACTIVATED',
        lastVerifiedAt: state.lastVerifiedAt ? new Date(state.lastVerifiedAt).toISOString() : null,
        plan: state.plan || 'none',
        features: state.features || []
      });
    });
    return true;
  }
});
