document.addEventListener('DOMContentLoaded', async () => {
  const badge = document.getElementById('badge');
  const keyInput = document.getElementById('key-input');
  const activateBtn = document.getElementById('activate-btn');
  const copyDiagBtn = document.getElementById('copy-diag-btn');

  // Format key input on typing
  keyInput.addEventListener('input', (e) => {
    let val = e.target.value.toUpperCase().replace(/[^0-9A-HJ-NP-Z*~$=]/g, '');
    let parts = [];
    for (let i = 0; i < val.length && i < 21; i += 5) {
      parts.push(val.slice(i, i + 5));
    }
    e.target.value = parts.join('-');
  });

  copyDiagBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'GET_DIAGNOSTICS' }, (diag) => {
      const text = JSON.stringify(diag, null, 2);
      navigator.clipboard.writeText(text).then(() => {
        copyDiagBtn.textContent = 'Copied!';
        setTimeout(() => { copyDiagBtn.textContent = 'Copy Diagnostics'; }, 2000);
      });
    });
  });
});
